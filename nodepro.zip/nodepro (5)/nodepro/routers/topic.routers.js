const router = require('express').Router();
const Topiccontroller = require("../controller/topic.controller");

router.post('/storeTopic',Topiccontroller.createTopic);
router.post('/getUserTopicList', Topiccontroller.getUserTopic);
router.post('/updateTopic', Topiccontroller.updateTopic); 
router.post('/deleteTopic',Topiccontroller.deleteTopic);
router.post('/getSearchTopics', Topiccontroller.getSearchTopics);




module.exports = router;



