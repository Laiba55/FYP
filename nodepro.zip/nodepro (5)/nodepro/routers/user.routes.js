const router = require('express').Router();
var cors = require("cors")
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      // Set the destination folder where the image will be saved
      cb(null, 'images/');
    },
    filename: function (req, file, cb) {
      // Append a timestamp to the original filename to make it unique
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, uniqueSuffix + '-' + file.originalname );
    }
  });
  const upload = multer({ storage: storage });

  
const usercontroller = require('../controller/user.controller');
router.use(cors());
router.post('/registration', usercontroller.register);
router.post('/login', usercontroller.login);
router.patch('/update-profile', usercontroller.updateProfile);



// sent OTP 
router.post("/otp", usercontroller.sendOtp);

// verify OTP
router.post("/verify-otp", usercontroller.verifyOtp);

// reset password
router.post("/reset-password", usercontroller.resetPassword);

// reset password
router.post("/change-password", usercontroller.changePassword);

// save image
router.post("/uploadfile", upload.single('image'), usercontroller.saveImage);

module.exports = router;