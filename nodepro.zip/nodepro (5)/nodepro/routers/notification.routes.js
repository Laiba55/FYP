const express = require('express');
const notificationController = require('../controller/notification.controller'); // Ensure proper import
const topicController = require('../controller/topic.controller'); // Import your topic-related controllers
const Topicservices = require('../services/topic.services');
const router = express.Router();
const Notification = require('../model/notification.model'); 

router.post('/notifications', notificationController.createNotification);
router.get('/notifications/:recipientUserId', async (req, res) => {
    try {
      const notifications = await Notification.find({ recipientUserId: req.params.recipientUserId });
      res.status(200).json({ notifications });
    } catch (error) {
      console.error('Error fetching notifications:', error);
      res.status(500).json({ error: 'Failed to fetch notifications.' });
    }
});


router.post('/send-notification', async (req, res) => {
  const { token, title, body, data } = req.body;
  try {
    const response = await NotificationService.sendNotification(token, title, body, data);
    res.status(200).send(response);
  } catch (error) {
    res.status(500).send(error);
  }
});
router.post('/accept-topic', topicController.acceptTopic); // Your function to handle topic acceptance
router.post('/payment-complete', notificationController.paymentComplete); // Function to handle payment completion

module.exports = router; // Export the router for use in your Express app
