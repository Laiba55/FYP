// event.routes.js
const express = require('express');
const router = express.Router();
const eventController = require('../controller/event.controller');

const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        // cb(null, Date.now() + path.extname(file.originalname));
        cb(null, file.originalname);
    }
});


function checkFileType(file, cb) {
    // Allowed filetypes
    const filetypes = /jpeg|jpg|png/;
    // Check the mimetype
    const mimetype = filetypes.test(file.mimetype);
    // Check the file extension
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());

    if (mimetype && extname) {
        return cb(null, true);
    } else {
        cb('Error: Images only! Allowed filetypes are .jpeg, .jpg, .png');
    }
}

const upload = multer({ 
    storage: storage,
    fileFilter: function (req, file, cb) {
        checkFileType(file, cb);
    }
}).single('image'); 

// router.post('/events', eventController.createEvent);




// const upload = multer({ storage: storage });

// router.post('/events', upload.single('image'), eventController.createEvent);


// const upload = multer({ 
//     storage: storage,
//     fileFilter: function (req, file, cb) {
//         checkFileType(file, cb);
//     }
// }).single('image'); 


router.post('/events', upload, eventController.createEvent);

module.exports = router;
