const express = require('express');
const NotificationService = require('../services/notification.service');

const router = express.Router();

router.post('/check-pending-notifications', async (req, res) => {
  try {
    const { userId } = req.body;
    const pendingNotifications = await NotificationService.checkPendingNotifications(userId);
    res.status(200).json({ success: true, pendingNotifications });
  } catch (error) {
    console.error('Error checking pending notifications:', error);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
});

module.exports = router;
