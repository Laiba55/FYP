const express = require('express');
const router = express.Router();
const admin = require('firebase-admin');



// Example route for registering FCM token
router.post('/register-fcm-token', async (req, res) => {
  const { token } = req.body;
  try {
    const response = await admin.messaging().subscribeToTopic(token, 'your_topic');
    res.status(200).send('Successfully registered FCM token');
  } catch (error) {
    console.error('Error registering FCM token:', error);
    res.status(500).send({ error: 'Internal Server Error' });
  }
});

module.exports = router;
