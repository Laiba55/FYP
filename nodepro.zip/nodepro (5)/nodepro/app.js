const express = require('express');
const cors = require('cors');
const body_parser = require('body-parser');
const userroutes = require('./routers/user.routes');
const Topicrouter = require('./routers/topic.routers');
const eventRoutes = require('./routers/events.routes');
const notificationRouter = require('./routers/notification.routes'); 
const NotificationService = require('./services/notification.service');
const checkNotificationsRouter = require('./routers/check-notifications.routes'); // New route
const NotificationModel = require('./model/notification.model');

const path = require('path');
const mongoose = require('mongoose');
const app = express();

app.use(cors());
app.use(body_parser.json());
app.use('/',userroutes)
app.use("/",Topicrouter);
app.use('/', eventRoutes);
app.use('/', notificationRouter);
app.use('/', checkNotificationsRouter); 


app.post('/api/notifications', async (req, res) => {
  try {
    const { userId, recipientUserId, title, body } = req.body;
    const notification = new NotificationModel({ userId, title,recipientUserId, body });
    await notification.save();
    res.status(201).json({ message: 'Notification stored successfully' });
  } catch (error) {
    console.error('Error storing notification:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});



app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong!');
});
// view image
app.get('/images/:filename', (req, res) => {
    const filename = req.params.filename;
    res.sendFile(path.join(__dirname, 'images', filename));
  })
module.exports = app;