const db = require('../config/db');
const mongoose = require('mongoose');
const usermodel = require("../model/user.model")


const { Schema } = mongoose;


const topicSchema = new Schema({
    userId: {
        type: Schema.Types.ObjectId,
        ref: usermodel.modelName
    },
    title: {
        type: String,
        required: true,
    },
    categories: {
        type: [String],
        required: true,
    },
    desc: {
        type: String,
        required: true,
    },
    topicId: {
        type: Schema.Types.ObjectId, // Adjust as needed
        ref: 'Notification' // Adjust as needed
    }
});





// const Topicmodel = db.model('topic', topicSchema);

const Topicmodel = mongoose.model('Topic', topicSchema);
module.exports= Topicmodel;