const mongoose = require('mongoose');
const db = require('../config/db');
const bcrypt = require("bcrypt");

const { Schema } = mongoose;
const userSchema = new Schema({
    email: {
        type: String,
        lowercase: true,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
    },
    firstName:{
        type:String,
        
    },
    lastName:{
        type:String,
    },
    phoneNumber:{
        type:String
    },
    address:{
        type:String,
    },
    otp: {
        type: String,
        required: false,
        default: null,
    },
    otpExpiry: {
        type: Date,
        required: false,
        default: null,
    },
    imageUrl: {
        type: String,
        required: false,
        default: null,
    },
    fcmToken: {
        type:String,
        default: 'fyd8vSgHSJiQnrLXfWId0N:APA91bHej7Ws1MFLFOW6WPAjNDHXPwqPqb5MrUcFbHz_Mopx4amVgRTwwiOfkvSXQVN65VDoJZ1DbOT0s3XxJ9HWWKTixhoX_hTwELqGdt4G_aWpwouDx-aHnxoalioa5oRkTPgYIsBK',    },

});

userSchema.pre('save', async function () {
    try {
        var user = this;
        if (user.password) {
            const salt = await bcrypt.genSalt(10);
            const hashpass = await bcrypt.hash(user.password, salt);
            user.password = hashpass;
        }
    } catch (error) {
        throw error;
    }
});


userSchema.methods.comparepass = async function (userpassword) {
    try {
        const isMatch = await bcrypt.compareSync(userpassword, this.password);
        return isMatch;
    } catch (error) {
        throw error;
    }
};

const usermodel = db.model('user', userSchema);

module.exports = usermodel;