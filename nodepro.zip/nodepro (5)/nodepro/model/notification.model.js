const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  userId: { type: String, required: true },

  title: {
    type: String,
    required: true,
  },
  body: {
    type: String,
    required: true,
  },
  recipientUserId: {
    type: mongoose.Schema.Types.ObjectId, // Only define type once
    required: true,
    ref: 'User' // Reference to the User model
  },
  topicId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Topic', // Reference to a related topic, if needed
  },
  timestamp: {
    type: Date,
    default: Date.now 
  },
  status: { type: String, enum: ['unread', 'read'], default: 'unread' } // Add status field
});

const Notification = mongoose.model('Notification', notificationSchema);

module.exports = Notification;
