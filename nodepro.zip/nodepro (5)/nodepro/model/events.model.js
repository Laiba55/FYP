const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    title: {
        type: String,
        required: true
    },
    details: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    time: {
            type: String, 
            required: true
    },
    imageURL: {
        type: String
    }
});

const Event = mongoose.model('Event', eventSchema);

module.exports = Event;
