const { response } = require('../app');
const userservice = require('../services/user.services');
const UserModel = require('../model/user.model');


exports.register = async (req, res, next) => {
    try {
        const { email, password, firstName, lastName, phoneNumber, address } = req.body;

        if (!email || !password || !firstName || !lastName || !address) {
            return res.status(400).json({ status: false, error: 'All fields are required' });
        }

        const successres = await userservice.registration(email, password, firstName, lastName,phoneNumber, address);
        
        if (successres) {
            res.json({ status: true, success: "User registered successfully" });
        } else {
            res.status(500).json({ status: false, error: 'An error occurred during registration' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ status: false, error: 'An error occurred during registration' });
    }
}

exports.login = async (req, res, next) => {
    try {
        const { email, password } = req.body;
        const user = await userservice.checkuser(email);

        if (!user) {
            return res.status(401).json({ status: false, error: 'User does not exist' });
        }

        const isMatch = await user.comparepass(password);

        if (!isMatch) {
            return res.status(401).json({ status: false, error: 'Invalid password' });
        }

        let tokendata = { _id: user._id, email: user.email };
        const token = await userservice.generatetoken(tokendata, "secretKey", '1h');
        res.status(200).json({                   
            status: true,
            token: token,
            userId: user._id,
            firstName: user.firstName,
            lastName: user.lastName,
            address: user.address,
            phoneNumber: user.phoneNumber,
        });
    } catch (error) {
        console.error(error); 
        res.status(500).json({ status: false, error: 'An error occurred during login' });
    }
}

// Inside user.controller.js
exports.updateProfile = async (req, res, next) => {
    try {
        const { userId } = req.body; // Extract user ID from request body
        const updatedUser = await userservice.updateUserProfile(userId, req.body);
        res.status(200).json({ status: true, user: updatedUser });
    } catch (error) {
        console.error(error);
        res.status(500).json({ status: false, error: 'An error occurred during profile update' });
    }
};



// 2nd iter
exports.sendOtp = async (req, res, next) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                message: "Email is required.",
            });
        };
        const otp = Math.floor(100000 + Math.random() * 900000);
        const currentTime = new Date();
        const otpExpiry = new Date(currentTime.getTime() + 30 * 60000);
        const sendEmail = await userservice.sendOtpEmail({ otp, receivers: email });
        if (!sendEmail) {
            return res.status(400).json({
                message: "An error occurred while sending email.",
            });
        };
        const updateUser = await userservice.saveOtpInDb(otp, otpExpiry, email);

        if (!updateUser) {
            return res.status(400).json({
                message: "An error occured in saving OTP in DB.",
            });
        };
        const resetToken = await userservice.generatetoken({ email, userId: updateUser._id, otp }, "secretKey", '30min')
        return res.status(200).json({ success: true, message: "OTP sent successfully.", resetToken });
    } catch (error) {
        console.log("🚀 ~ file: auth.controller.js:248 ~ sendOTP ~ error:", error)
        res.status(500).json({ status: false, error: 'An error occurred in sending otp' });
    };
};

exports.verifyOtp = async (req, res, next) => {
    try {
        const { resetToken, otp } = req.body;
        const { email, userId, otp: decodedOtp } = await userservice.decodetoken(resetToken, "secretkey");
        if (!email) {
            return res.status(400).json({
                message: "Invalid Token",
            });
        };
        if (!otp) {
            return res.status(400).json({
                message: "OTP required.",
            });
        };
        if (!decodedOtp) {
            return res.status(400).json({
                message: "Invalid Token",
            });
        };

        if (String(otp) !== String(decodedOtp)) {
            return res.status(400).json({
                message: "Invalid OTP.",
            });
        }
        const user = await userservice.findUserToVerifyOtp(email, otp);
        if (!user) {
            return res.status(400).json({
                message: "Invalid or expired OTP.",
            });
        };
        await userservice.otpVerified(userId);
        return res.status(200).json({ success: true, message: "OTP verified successfully." });
    } catch (error) {
        console.log("🚀 ~ file: auth.controller.js:248 ~ sendOTP ~ error:", error)
        res.status(500).json({ status: false, error: 'An error occurred in verifying otp' });
    };
};

exports.resetPassword = async (req, res, next) => {
    try {
        const { resetToken, password } = req.body;
        const { email } = await userservice.decodetoken(resetToken, "secretkey");
        if (!email) {
            return res.status(400).json({
                message: "Invalid Token.",
            });
        };
        if (!password) {
            return res.status(400).json({
                message: "Password is required.",
            });
        };
        const user = await userservice.findUserByEmail(email);
        if (!user) {
            return res.status(400).json({
                message: "Invalid token",
            });
        };
        await userservice.resetPassword(user, password);
        return res.status(200).json({ success: true, message: "Password updated successfully." });
    } catch (error) {
        console.log("🚀 ~ file: user.controller.js:248 ~ reset pass ~ error:", error)
        res.status(500).json({ status: false, error: 'An error occurred in resetting password' });
    };
};

exports.changePassword = async (req, res, next) => {
    try {
        const { oldPassword, newPassword, email } = req.body;
        const user = await userservice.changePassword(email, oldPassword, newPassword);
        await userservice.resetPassword(user, newPassword);
        return res.status(200).json({ success: true, message: "Password updated successfully." });
    } catch (error) {
        console.log("🚀 ~ file: user.controller.js:144 ~ exports.changePassword= ~ error:", error)
        res.status(500).json({ status: false, message: 'An error occurred in changing password', error: error.message });
    }
};
exports.saveImage = async (req, res, next) => {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(400).json({
                message: "Email is required.",
            });
        }
        if (!req.file) {
            return res.status(404).send('Image not provided.');
          }      
        const imageUrl = `http://localhost:3000/images/${req.file.filename}`;
        const user = await userservice.saveImage(email, imageUrl);
        res.status(201).json({ upload: true, user });
    } catch (error) {
        res.status(500).json({ status: false, message: 'An error occurred in changing password', error: error.message });
    };
}