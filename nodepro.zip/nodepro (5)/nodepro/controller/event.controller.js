const Event = require('../model/events.model');

exports.createEvent = async (req, res) => {
    try {
        const { userId, title, details, date, time } = req.body;
        const imageURL = req.file ? req.file.path : null;
        
        // Check if the time field is provided
        if (!time) {
            return res.status(400).json({ success: false, error: 'Time field is required' });
        }

        const newEvent = new Event({
            userId,
            title,
            details,
            imageURL,
            date,
            time
        });

        await newEvent.save();
        res.status(201).json({ success: true, message: 'Event created successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
};



// Controller function to retrieve all events for a user
exports.getUserEvents = async (req, res) => {
    try {
        const userId = req.params.userId;
        const events = await Event.find({ userId });
        res.status(200).json({ success: true, events });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
};
