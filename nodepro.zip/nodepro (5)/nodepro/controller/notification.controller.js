const NotificationService = require('../services/notification.service'); // Import the NotificationService only once
const Notification = require('../model/notification.model'); 
const Topicservices = require('../services/topic.services'); 
const UserServices = require('../services/user.services'); 
const { generateMeetingCode } = require('../utils');
const mongoose = require('mongoose');
const Topic = require('../model/topic.model');




exports.createNotification = async (req, res) => {
  try {
      const { userId, title, body, recipientUserId, topicId } = req.body;

      const notification = new Notification({
          userId,
          title,
          body,
          recipientUserId,
          topicId
      });

      await notification.save();

      res.status(201).json({ message: 'Notification stored successfully' });
  } catch (error) {
      console.error('Error storing notification:', error);
      res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getUserNotifications = async (req, res) => {
  try {
      const { userId } = req.params;
      const notifications = await Notification.find({ recipientUserId: userId });
      
      await Notification.updateMany({ recipientUserId: userId }, { $set: { status: 'read' } });
      
      res.json({ success: true, notifications });
  } catch (error) {
      console.error('Error retrieving notifications:', error);
      res.status(500).json({ success: false, message: 'Error retrieving notifications', error: error.message });
  }
};







exports.paymentComplete = async (req, res) => {
    try {
        const { userId, recipientUserId } = req.body; // Extract recipientUserId from the request body

        // Validate the user ID
        if (!mongoose.Types.ObjectId.isValid(userId) || !mongoose.Types.ObjectId.isValid(recipientUserId)) {
            return res.status(400).json({ error: 'Invalid user ID or recipient user ID' });
        }

        // Retrieve user details from the database
        const user = await UserServices.getUserById(userId);
        if (!user || !user.fcmToken) {
            return res.status(404).json({ error: 'User not found.' });
        }

        // Generate a meeting code
        const meetingCode = generateMeetingCode();

        // Create a new notification object
        const notification = new Notification({
            userId: userId,
            recipientUserId: recipientUserId, // Include recipientUserId in the notification object
            title: 'Payment Received',
            body: `The payment is confirmed. The meeting code is: ${meetingCode}`,
            // Add any additional fields you need
        });

        // Send a push notification to the user
        const title = 'Payment Received';
        const body = `The payment is confirmed. The meeting code is: ${meetingCode}`;
        await NotificationService.sendNotification(
            user.fcmToken,
            title,
            body,
            { meetingCode }
        );

        // Save the notification to the database
        await notification.save();

        // Send a response indicating success
        res.status(200).json({ message: 'Payment notification sent and saved to database.' });
    } catch (error) {
        // Handle any errors that occur during the process
        console.error('Error in paymentComplete:', error);
        res.status(500).json({ error: 'Internal server error.' });
    }
}; 



// exports.paymentComplete = async (req, res) => {
//     try {
//         const { userId } = req.body; // Extract payer's user ID from the request body

//         // Validate the user ID
//         if (!mongoose.Types.ObjectId.isValid(userId)) {
//             return res.status(400).json({ error: 'Invalid user ID' });
//         }

//         // Retrieve user details from the database
//         const user = await UserServices.getUserById(userId);
//         if (!user || !user.fcmToken) {
//             return res.status(404).json({ error: 'User not found.' });
//         }

//         // Here, you need to implement the logic to determine the recipient user based on the payer's ID
//         // For example, if there's a direct relationship between payer and recipient, you can use that to find the recipient's ID

//         const recipientUserId = determineRecipientUserId(userId); // Implement this function to determine the recipient user's ID
        
//         if (!recipientUserId) {
//             return res.status(404).json({ error: 'Recipient user ID not found.' });
//         }

//         // Generate a meeting code
//         const meetingCode = generateMeetingCode();

//         // Create a new notification object for the payer
//         const payerNotification = new Notification({
//             userId: userId,
//             recipientUserId: recipientUserId, // Include recipientUserId in the notification object
//             title: 'Payment Received',
//             body: `The payment is confirmed. The meeting code is: ${meetingCode}`,
//         });

//         // Create a new notification object for the recipient
//         const recipientNotification = new Notification({
//             userId: recipientUserId,
//             recipientUserId: userId, // Reverse the recipient and payer for the recipient's notification
//             title: 'Payment Received',
//             body: `You have received a payment. The meeting code is: ${meetingCode}`,
//         });

//         // Send push notifications to both the payer and the recipient
//         const title = 'Payment Received';
//         const body = `The payment is confirmed. The meeting code is: ${meetingCode}`;
//         await Promise.all([
//             NotificationService.sendNotification(user.fcmToken, title, body, { meetingCode }), // Notification to payer
//             NotificationService.sendNotification(recipientUser.fcmToken, title, body, { meetingCode }) // Notification to recipient
//         ]);

//         // Save the notifications to the database
//         await Promise.all([
//             payerNotification.save(),
//             recipientNotification.save()
//         ]);

//         // Send a response indicating success
//         res.status(200).json({ message: 'Payment notifications sent and saved to database.' });
//     } catch (error) {
//         // Handle any errors that occur during the process
//         console.error('Error in paymentComplete:', error);
//         res.status(500).json({ error: 'Internal server error.' });
//     }
// };





