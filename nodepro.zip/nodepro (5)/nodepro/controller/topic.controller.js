const Topicservices = require("../services/topic.services");
const mongoose = require('mongoose'); 
const Notification = require('../model/notification.model');
const NotificationService = require('../services/notification.service');
const Topicmodel = require("../model/topic.model");
const { getTopicById } = require('../services/topic.services'); // Adjust to where your function is defined
const { getUserById } = require('../services/user.services'); // Adjust path to where `getUserById` is defined

const userservice = require('../services/user.services'); // Ensure the correct import


exports.createTopic = async (req, res, next) => {
    try {
        const { userId, title,categories, desc } = req.body;

        let topic = await Topicservices.createTopic(userId, title,categories, desc);

        res.json({ status: true, success: topic });
    }
    catch (error) {
        next(error);
    }

}
exports.getUserTopic = async (req, res, next) => {
    try {
        const { userId } = req.body;

        const objectIdUserId = new mongoose.Types.ObjectId(userId.toString());
        console.log('userId before calling getUserTopic:', userId);

       let topic = await Topicservices.getTopicdata(userId);
        // let topic = await Topicservices.getTopicdata(userId);
        console.log('Topic data:', topic);
        res.json({ status: true, success: topic });
    }
    catch (error) {
        console.error('Error in getUserTopic:', error);
        next(error);
    }

}

exports.updateTopic = async (req, res, next) => {
    try {
        const { id, title,categories, desc } = req.body;
        let updatedTopic = await Topicservices.updateTopic(id, title,categories, desc);
        res.json({ status: true, success: updatedTopic });
    } catch (error) {
        next(error);
    }
}


exports.deleteTopic = async (req, res, next) => {
    try {
        const { id } = req.body;

        let deleted = await Topicservices.deleteTopic(id);

        res.json({ status: true, success: deleted });
    }
    catch (error) {
        next(error);
    }

}
exports.getSearchTopics = async (req, res, next) => {
    try {
        const { userId } = req.body; 
        if (!userId) {
            console.log('User ID is undefined or null.');
            return res.json({ status: false, error: 'User ID is required.' });
          }
          
        console.log('Received request for /getSearchTopics with userId:', userId);

        console.log('Before fetching search topics');
        let searchTopics = await Topicservices.getSearchTopics(userId);
        console.log('After fetching search topics:', searchTopics);
       
        res.json({ status: true, success: searchTopics });
    } catch (error) {
        console.error(error);
        next(error);
    }
}

// exports.acceptTopic = async (req, res) => {
//     try {
//         const { topicId, userId } = req.body;
//         console.log('Received topicId:', topicId);
//         console.log('Received userId:', userId);

//         if (!mongoose.Types.ObjectId.isValid(topicId) || !mongoose.Types.ObjectId.isValid(userId)) {
//             return res.status(400).json({ error: 'Invalid userId or topicId' });
//         }

//         // Find the topic
//         const topic = await getTopicById(topicId);
//         if (!topic) {
//             console.error('Topic not found');
//             return res.status(404).json({ error: 'Topic not found' });
//         }

//         // Find the topic owner
//         const topicOwner = await getUserById(userId);
//         if (!topicOwner) {
//             console.error('Topic owner not found');
//             return res.status(404).json({ error: 'Topic owner not found' });
//         }
        
//         if (!topicOwner.fcmToken) {
//             console.error('No FCM token for topic owner');
//             return res.status(404).json({ error: 'Topic owner does not have an FCM token' });
//         }

//        // Save notification to MongoDB
//         const notification = new Notification({
//             userId: topic.userId, // Sender's userId
//             title: 'Topic Accepted',
//             body: 'Your topic has been accepted. Please make the payment.',
//             recipientUserId: userId, // Recipient's userId
//             topicId: topicId
//         });
//         await notification.save();
//         // Send notification to the topic owner
//         await NotificationService.sendNotification(
//             topicOwner.fcmToken,
//             'Topic Accepted',
//             'Your topic has been accepted. Please make the payment.',
//             { topicId: topic._id.toString() }
//         );


//         res.json({ success: true, message: 'Notification sent successfully' });
//     } catch (error) {
//         console.error('Error in acceptTopic:', error);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// };


// In acceptTopic function




exports.acceptTopic = async (req, res) => {
    try {
        const { topicId, userId } = req.body;
        console.log('Received topicId:', topicId);
        console.log('Received userId:', userId);

        // Validate input
        if (!mongoose.Types.ObjectId.isValid(topicId)) {
            console.error('Invalid topicId');
            return res.status(400).json({ error: 'Invalid topic ID' });
        }

        if (!mongoose.Types.ObjectId.isValid(userId)) {
            console.error('Invalid userId');
            return res.status(400).json({ error: 'Invalid user ID' });
        }

        // Fetch topic and user data
        const topic = await getTopicById(topicId);
        if (!topic) {
            console.error('Topic not found');
            return res.status(404).json({ error: 'Topic not found' });
        }
        console.log('Topic fetched:', topic);

        const topicOwner = await getUserById(topic.userId);
        if (!topicOwner) {
            console.error('Topic owner not found');
            return res.status(404).json({ error: 'Topic owner not found' });
        }
        console.log('Topic owner fetched:', topicOwner);

        // Save notification to MongoDB
        const notification = new Notification({
            userId: topic.userId,
            title: 'Topic Accepted',
            body: 'Your topic has been accepted. Please make the payment.',
            recipientUserId: topic.userId,
            topicId: topicId
        });
        await notification.save();
        console.log('Notification saved:', notification);

        // Send notification to the topic owner
        await NotificationService.sendNotification(
            topicOwner.fcmToken,
            'Topic Accepted',
            'Your topic has been accepted. Please make the payment.',
            { topicId: topic._id.toString() }
        );
        console.log('Notification sent to topic owner');

        res.json({ success: true, message: 'Notification sent successfully' });
    } catch (error) {
        console.error('Error in acceptTopic:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
