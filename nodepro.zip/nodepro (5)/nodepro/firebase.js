const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json'); // Correct path to service account key

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

class NotificationService {
  static async sendNotification(token, title, body, data = {}) {
    try {
      const message = {
        notification: {
          title,
          body,
        },
        data,
        token, // FCM token of the target device
      };

      const response = await admin.messaging().send(message);
      console.log('Notification sent:', response);
      return response;
    } catch (error) {
      console.error('Error sending notification:', error);
      throw error;
    }
  }
}

module.exports = NotificationService;

module.exports = admin; // Export the Firebase Admin instance for use elsewhere




































// const admin = require('firebase-admin');

// class NotificationService {
//   static async sendNotification(token, title, body, data = {}) {
//     try {
//       const message = {
//         notification: {
//           title,
//           body,
//         },
//         data, // Additional data for the notification, like topicId
//         token, // FCM token of the target user
//       };

//       const response = await admin.messaging().send(message);
//       console.log('Successfully sent message:', response);
//       return response;
//     } catch (error) {
//       console.error('Error sending message:', error);
//       throw error;
//     }
//   }
// }

// module.exports = NotificationService;
