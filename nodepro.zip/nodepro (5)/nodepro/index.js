const app = require('./app');
const db = require('./config/db');
const usermodel = require('./model/user.model');
const Topicmodel = require('./model/topic.model');
const eventmodel= require('./model/events.model');
const notificationmodel= require('./model/notification.model');
const mongoose = require('mongoose');


const port = 3000;
app.get('/', (req,res)=>{
    res.send("helloooo")
})


app.listen(port, ()=>{
    console.log(`server running on http://localhost:${port}`);
})



