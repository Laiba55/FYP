const Topicmodel = require("../model/topic.model");
const mongoose = require('mongoose');


class Topicservices {
    static async createTopic(userId, title,categories, desc) {
        const createTopic = new Topicmodel({ userId, title,categories, desc });
       
        return await createTopic.save();
    }

    static async getTopicById(topicId) {
        if (!mongoose.Types.ObjectId.isValid(topicId)) {
            throw new Error('Invalid topic ID');
        }
        return await Topicmodel.findById(topicId);
    }


   



    static async getTopicdata(userId) {

        try {
            console.log('userId before creating ObjectId:', userId);
            const topicData = await Topicmodel.find({ userId });
            return topicData;
        } catch (error) {
            console.error('Error in getTopicdata:', error);
            throw error;
       
        }
        // console.log('userId:', userId)
        // const objectIdUserId = mongoose.Types.ObjectId(userId);

        // const topicData = await Topicmodel.find({ userId: objectIdUserId });

        // const topicData = await Topicmodel.find({ userId });
        // let topic = await Topicservices.getTopicdata(new mongoose.Types.ObjectId(userId));

        // return topicData;
    }

    static async updateTopic(id, title,categories, desc) {
        const updatedTopic = await Topicmodel.findByIdAndUpdate(id, { title,categories, desc }, { new: true });
        return updatedTopic;
    }
    
    static async deleteTopic(id) {
        const deleted = await Topicmodel.findOneAndDelete({ _id: id });
        return deleted;
    }

    static async getSearchTopics(userId) {
        try {
            const searchTopics = await Topicmodel.find({ userId: { $ne: userId } });
            return searchTopics;
        } catch (error) {
            console.error('Error in getSearchTopics:', error);
            throw error;
        }
    }
    

    

    
    

}
module.exports = Topicservices;

