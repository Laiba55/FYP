const usermodel = require('../model/user.model');
const mongoose = require('mongoose');
const jwt= require('jsonwebtoken');
const { response } = require('../app');
const nodemailer = require('nodemailer');
const bcrypt = require("bcrypt");
const emailTemplate = require("../utils/email.template");


class userservice{
    static async registration(email, password, firstName, lastName, phoneNumber, address){
        try{
            const createuser = new usermodel({
                email,
                password,
                firstName,
                lastName,
                phoneNumber,
                address,
             });
            return await createuser.save();
        }
    catch(err){
        throw err;

    }
    }

    static async checkuser(email){
        try{
            return await usermodel.findOne({email});
        }catch(err){
            throw err;
        }
    }

       static async generatetoken(tokendata,secretKey, jwt_expire){
        return jwt.sign(tokendata, secretKey,{expiresIn:jwt_expire});
    } 
    


static async updateUserProfile(userId, updatedData) {
    try {
        return await usermodel.findByIdAndUpdate(userId, updatedData, { new: true });
    } catch (error) {
        throw error;
    }
}





    // 2nd iter
    static async decodetoken(token, secretKey) {
        return jwt.decode(token, secretKey);
    };
    static async sendOtpEmail({ otp, receivers }) {
        try {
            const transporter = nodemailer.createTransport({
                host: "smtp-mail.outlook.com",
                secureConnection: false, // TLS requires secureConnection to be false
                port: 587, // port for secure SMTP
                auth: {
                    user: "ramshashahid644@outlook.com",
                    pass: "ramsha.100"
                },
                tls: {
                    ciphers: 'SSLv3'
                }
            });
            const template = emailTemplate.otpTemplate(otp);
            const mailOptions = {
                from: "ramshashahid644@outlook.com",
                to: receivers,
                subject: "OTP to reset password",
                html: template,
            };
            const sendEmail = await transporter.sendMail(mailOptions);
            console.log(sendEmail)
            return sendEmail;
        } catch (error) {
            throw error;
        };
    };
    static async saveOtpInDb(otp, otpExpiry, email) {
        try {
            const updateUser = await usermodel.findOneAndUpdate({ email }, { otp, otpExpiry }, { new: true });
            return updateUser;
        } catch (error) {
            throw error;
        };
    };
    static async findUserToVerifyOtp(email, otp) {
        try {
            const currentTime = new Date();
            const user = await usermodel.findOne({ email, otp, otpExpiry: { $gt: currentTime } });
            return user;
        } catch (error) {
            throw error;
        }
    };
    static async otpVerified(userId) {
        try {
            return await usermodel.findOneAndUpdate({ _id: userId }, { otp: null, otpExpiry: null }, { new: true });
        } catch (error) {
            throw error
        }
    };
    static async findUserByEmail(email) {
        try {
            return await usermodel.findOne({ email });
        } catch (error) {
            throw error;
        }
    };
    static async resetPassword(user, password) {
        try {
            const salt = await (bcrypt.genSalt(10));
            const hashpass = await bcrypt.hash(password, salt);
            return await usermodel.findByIdAndUpdate({_id: user._id}, {password: hashpass}, {new: true});
        } catch (error) {
            throw error;
        };
    };
    static async changePassword(email, oldPassword) {
        try {
            const user = await usermodel.findOne({ email });
            const isMatch = await user.comparepass(oldPassword);
            console.log("🚀 ~ file: user.services.js:102 ~ userservice ~ changePassword ~ isMatch:", isMatch)
            if (!isMatch) {
                throw new Error('Incorrect password!');
            };
            return user;
        } catch (error) {
            throw error;
        };
    };
    static async saveImage(email, imageUrl) {
        try {
            const user = await usermodel.findOneAndUpdate({ email }, { imageUrl }, { new: true });
            return user;
        } catch (error) {
            throw error;
        }
    }
//     static async getUserById(userId) {
//         if (!mongoose.Types.ObjectId.isValid(userId)) {
//             throw new Error('Invalid user ID');
//         }
//         return await usermodel.findById(userId);
//     }
// }
static async getUserById(userId) {
    console.log(`Fetching user with ID: ${userId}`);

    if (!mongoose.Types.ObjectId.isValid(userId)) {
        throw new Error('Invalid user ID');
    }

    try {
        const user = await usermodel.findById(userId); // Changed from User.findById(userId) to usermodel.findById(userId)
        return user;
    } catch (error) {
        console.error('Error fetching user by ID:', error);
        throw error;
    }
}
}

module.exports = userservice;
