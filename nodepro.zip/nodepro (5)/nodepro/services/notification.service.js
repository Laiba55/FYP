const admin = require('firebase-admin');
const serviceAccount = require('../serviceAccountKey.json'); // Path to your service account key file
const User = require('../model/user.model'); 

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

class NotificationService {
  static async sendNotification(token, title, body, data) {
    if (!token) {
      console.error("No FCM token provided.");
      throw new Error("FCM token is required to send a notification.");
    }

    try {
      const message = {
        notification: {
          title,
          body,
        },
        data,
        token, // FCM token of the target device
      };

      const response = await admin.messaging().send(message);
      console.log('Notification sent:', response);
      return response;
    } catch (error) {
      console.error('Error sending notification:', error);
      throw error; // Rethrow to ensure proper error handling
    }
  }
  
//   static async registerFCMToken(userId, fcmToken) {
//     try {
//         console.log(`Registering FCM token for user ID: ${userId}`);
        
//         // Find the user by userId
//         let user = await User.findOne({ userId });

//         if (!user) {
//             // Create the user if not found
//             user = new User({ userId, fcmToken }); // Is userId enough to create a new user?
//             await user.save();
//             console.log('FCM token registered successfully for new user:', userId);
//         } else {
//             // Update the FCM token if user exists
//             user.fcmToken = fcmToken;
//             await user.save();
//             console.log('FCM token updated successfully for existing user:', userId);
//         }
//     } catch (error) {
//         console.error('Error registering FCM token:', error);
//         throw error;
//     }
// }
// }

static async checkPendingNotifications(userId) {
  try {
    // Assuming your Notification schema has a `userId` field and a `status` field to indicate if it's pending
    const pendingNotifications = await Notification.find({ userId, status: 'pending' }).exec();
    return pendingNotifications;
  } catch (error) {
    console.error('Error checking pending notifications:', error);
    throw error;
  }
}
}

module.exports = NotificationService;
