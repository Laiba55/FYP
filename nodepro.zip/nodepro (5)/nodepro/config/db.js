
const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/Wad', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log("MongoDb Connected");
})
.catch((error) => {
    console.error("MongoDb Connection error:", error);
});

module.exports = mongoose;
